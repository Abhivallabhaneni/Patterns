package Ques26;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public final class Class26 {
    private static final Class26 INSTANCE = new Class26();

    private Class26() {}

    public static Class26 getInstance() {
        return INSTANCE;
    }
}
