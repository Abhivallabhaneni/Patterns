package Ques19;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Implements implements Runnable {
    public void run() {
        System.out.println("Here the Thread running");
    }

    public static void main(String[] args) {
    	Implements A4 = new Implements();
        Thread T3 = new Thread(A4);
        T3.start();
    }
}
