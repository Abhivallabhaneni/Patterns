package Ques19;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Extends extends Thread {
    public void run() {
        System.out.println("Here the Thread is running");
    }

    public static void main(String[] args) {
    	Extends T4 = new Extends();
        T4.start();
    }
}

