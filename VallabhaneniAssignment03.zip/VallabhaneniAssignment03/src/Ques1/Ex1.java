package Ques1;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Ex1<String, Int> {
	private String Name;
	private Int Age;

	public Ex1(String Name, Int Age) {
		this.Name = Name;
		this.Age = Age;
	}

	public String getName() {
		return Name;
	}

	public Int getAge() {
		return Age;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public void setAge(Int Age) {
		this.Age = Age;
	}
}
