package Ques24;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Class24 {
    public static void main(String[] args) {
        for (int a = 0; a < 1000000; a++) {
            new Object();
        }
        
        // Explicitly call the garbage collector
        System.gc();
        
        // Wait for a moment to allow the garbage collector to run
        try {
            Thread.sleep(1000);
        } catch (InterruptedException A1) {
            A1.printStackTrace();
        }
        
        System.out.println("Garbage collection has collected");
    }
}
