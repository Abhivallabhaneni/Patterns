package Ques9;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Maincls1 {
	public static void main(String[] args) {
		try (BufferedReader B = new BufferedReader(new FileReader("Abhi.txt"))) {
			String L;
			while ((L = B.readLine()) != null) {
				System.out.println(L);
			}
		} catch (IOException e) {
			System.err.println("Error reading file: " + e.getMessage());
		}
	}
}
