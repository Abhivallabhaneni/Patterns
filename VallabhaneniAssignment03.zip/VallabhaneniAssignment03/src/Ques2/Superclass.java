package Ques2;

public class Superclass {
	    public void publicMethod() {
	        System.out.println("Public method in the superclass.");
	    }
	    
	    protected void protectedMethod() {
	        System.out.println("Protected method in the superclass.");
	    }
	    
	    void defaultMethod() {
	        System.out.println("Default method in the superclass.");
	    }
	    
	    private void privateMethod() {
	        System.out.println("Private method in the superclass.");
	    }
	}

	class Subclass extends Superclass {
	    // This method overrides a public method in the superclass.
	    public void publicMethod() {
	        System.out.println("Public method in the subclass.");
	    }
	    
	    // This method overrides a protected method in the superclass.
	    protected void protectedMethod() {
	        System.out.println("Protected method in the subclass.");
	    }
	    
	    // This method overrides a default method in the superclass.
	    void defaultMethod() {
	        System.out.println("Default method in the subclass.");
	    }
	    
	    // This method cannot override a private method in the superclass.
	    // private void privateMethod() {}
	}



