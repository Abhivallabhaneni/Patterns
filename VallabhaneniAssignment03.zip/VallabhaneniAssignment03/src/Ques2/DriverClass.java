package Ques2;

public class DriverClass {
	public static void main(String[] args) {
		Superclass obj1 = new Superclass();
		obj1.publicMethod(); 
		obj1.protectedMethod();
		obj1.defaultMethod();
		// obj1.privateMethod();

		Subclass obj2 = new Subclass();
		obj2.publicMethod(); 
		obj2.protectedMethod(); 
		obj2.defaultMethod(); 
		// obj2.privateMethod(); 
		// method.
	}
}
