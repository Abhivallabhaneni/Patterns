package Ques13;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

import java.util.*;

public class Class13 {

	public static void main(String[] args) {
		// Creating a Vector
		Vector<String> V13 = new Vector<>();

		// Adding elements to Vector
		V13.add("Audi");
		V13.add("Benz");
		V13.add("BMW");
		System.out.println("Vector: " + V13);

		// Creating an ArrayList
		ArrayList<String> AL13 = new ArrayList<>();

		// Adding elements to ArrayList
		AL13.add("RE");
		AL13.add("TVS");
		AL13.add("Bajaj");
		System.out.println("ArrayList: " + AL13);
	}
}
