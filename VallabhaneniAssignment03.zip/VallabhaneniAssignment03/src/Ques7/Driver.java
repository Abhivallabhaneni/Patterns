package Ques7;
/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Driver {
    public static void main(String[] args) {
        class1 c = new class1();
        // Use c here
    }
}

