package Ques7;
/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */
public class class1 {
	// This code will not compile
	// public final MyClass() {
	// // Constructor logic here
	// }

	public class1() {
		// Constructor logic here
	}
}
