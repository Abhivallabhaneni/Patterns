package Ques3;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class DriverClass {
	public static void main(String[] args) {

		SuperClass A1 = new SuperClass();
		A1.getSelf();

		Subclass A2 = new Subclass();
		A2.getSelf();

		SuperClass A3 = new Subclass();
		A3.getSelf();
	}
}
