package Ques3;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class SuperClass {
	SuperClass getSelf() {
		System.out.println("It's a method in the superclass.");
		return this;
	}
}

class Subclass extends SuperClass {
	Subclass getSelf() {
		System.out.println("It's a method in the subclass.");
		return this;
	}
}
