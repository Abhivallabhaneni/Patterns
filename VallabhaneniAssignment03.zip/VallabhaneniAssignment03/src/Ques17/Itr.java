package Ques17;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */


import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class Itr {
    public static void main(String[] args) {
        // Creating an ArrayList
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Abhi");
        arrayList.add("Hemanth");
        arrayList.add("Manideep");

        // Creating a fail-fast iterator
        Iterator<String> failFastIterator = arrayList.iterator();

        // Modifying the ArrayList while iterating over it
        while (failFastIterator.hasNext()) {
            String S17 = failFastIterator.next();
            if (S17.equals("Hemanth")) {
                arrayList.remove(S17);
            }
        }

        // Creating a fail-safe iterator
 CopyOnWriteArrayList<String> COWArrayList = new CopyOnWriteArrayList<>(arrayList);
        Iterator<String> failSafeIterator = COWArrayList.iterator();

        // Modifying the ArrayList while iterating over it
        while (failSafeIterator.hasNext()) {
            String S17_1 = failSafeIterator.next();
            if (S17_1.equals("Hemanth")) {
                COWArrayList.remove(S17_1);
            }
        }
    }
}
