package Ques8;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class MainCls {
	public static void main(String[] args) {
		try {
			// Code that may throw an exception here
			System.out.println("Here Try block executed");
		} finally {
			// Code that must be executed here
			System.out.println("Here Finally block executed");
		}
	}
}
