package Ques27;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public final class Class27 {
    private static volatile Class27 INSTANCE = null;

    private Class27() {}

    public static synchronized Class27 getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Class27();
        }
        return INSTANCE;
    }
}

