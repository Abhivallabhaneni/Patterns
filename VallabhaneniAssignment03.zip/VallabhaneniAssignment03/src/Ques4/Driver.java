package Ques4;
/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Driver {
	public static void main(String[] args) {
		Class.staticMethod(); 
		Subclass.staticMethod(); 

		// This code will not compile because privateMethod() is not visible in the subclass.

		Subclass A = new Subclass();
		A.publicMethod();
	}
}
