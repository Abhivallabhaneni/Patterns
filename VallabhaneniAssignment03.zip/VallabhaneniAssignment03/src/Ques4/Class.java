package Ques4;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

public class Class {
	    public static void staticMethod() {
	        System.out.println("It's a static method in the superclass.");
	    }
	    
	    private void privateMethod() {
	        System.out.println("It's a private method in the superclass.");
	    }
	}

	class Subclass extends Class {
	    public static void staticMethod() {
	        System.out.println("It's a static method in the subclass.");
	    }
	    
	    public void publicMethod() {
	        System.out.println("It's a public method in the subclass.");
	    }
	}
