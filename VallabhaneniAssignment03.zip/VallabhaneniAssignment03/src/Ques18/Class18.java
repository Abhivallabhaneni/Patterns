package Ques18;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */


public class Class18 {
    public static void main(String[] args) {
        Thread thread = new Thread(() -> {
            System.out.println("Thread started from here");
        });
        
        // Starting the thread for the first time
        thread.start();
    }
}
