package Ques10;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */
import java.io.IOException;

public class Cls {
	void method() throws IOException, Exception {
		// method implementation
	}
}

class SubClass extends Cls {
// This will result in a compile-time error
	void method() throws Exception {
		// method implementation
	}
}
