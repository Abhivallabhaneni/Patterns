package Ques16;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

import java.util.HashMap;

public class Hash {
    public static void main(String[] args) {
        // Creating a HashMap
        HashMap<String, Integer> hashMap = new HashMap<>();

        // Adding elements to HashMap
        hashMap.put("Abhi", 9);
        hashMap.put("Hemanth", 99);
        hashMap.put("Manideep", 999);
        System.out.println("HashMap: " + hashMap);

        // Getting the value for a key
        int value = hashMap.get("Abhi");
        System.out.println("Value for Abhi: " + value);

        // Removing an entry from HashMap
        hashMap.remove("Hemanth");
        System.out.println("HashMap after removing Hemanth: " + hashMap);

        // Checking if a key exists in HashMap
        boolean exists = hashMap.containsKey("Manideep");
        System.out.println("Does Manideep exist in HashMap? " + exists);
    }
}
