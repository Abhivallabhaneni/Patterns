package Ques14;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

import java.util.*;

public class Class {
    public static void main(String[] args) {
        // Creating an ArrayList
        ArrayList<String> arrayList = new ArrayList<>();

        // Adding elements to ArrayList
        arrayList.add("Abhi");
        arrayList.add("Hemanth");
        arrayList.add("Manideep");
        System.out.println("ArrayList: " + arrayList);

        // Making ArrayList synchronized
        List<String> synchronizedList = Collections.synchronizedList(arrayList);

        // Adding elements to synchronized ArrayList
        synchronized(synchronizedList) {
            synchronizedList.add("Tarun");
            synchronizedList.add("Murali");
        }

        System.out.println("Synchronized ArrayList: " + synchronizedList);
    }
}
