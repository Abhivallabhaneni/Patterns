package Ques14;

/**
 * @author S556511 Abhilash Vallabhaneni
 *
 * 
 */

import java.util.*;

public class Class1 extends ArrayList<String> {
    @Override
    public synchronized boolean add(String S14) {
        return super.add(S14);
    }

    @Override
    public synchronized void add(int I, String E) {
        super.add(I, E);
    }

    // Override other methods as well...

    public static void main(String[] args) {
        // Creating a synchronized ArrayList
        Class1 synchronizedList = new Class1();

        // Adding elements to synchronized ArrayList
        synchronizedList.add("Abhi");
        synchronizedList.add("Hemanth");
        synchronizedList.add("Manideep");
        System.out.println("Synchronized ArrayList: " + synchronizedList);
    }
}
